export default function Top() {
  return (
    <section className="p-5 shadow-md bg-white">
      <h1 className="text-3xl font-bold">Welcome to the Dashboard page</h1>
    </section>
  );
}