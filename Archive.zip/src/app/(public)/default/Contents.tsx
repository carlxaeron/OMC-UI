export default function Contents() {
  return (
    <>
      <h2>Page</h2>
    </> 
  )
}