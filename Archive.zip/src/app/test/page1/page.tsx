import Layout from "../components/Layout";

export default function Page1() {
    return (
        <Layout>
            <h1>Page 1</h1>
        </Layout>
    );
}