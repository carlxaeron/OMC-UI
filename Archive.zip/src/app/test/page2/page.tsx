import Layout from "../components/Layout";

export default function Page2() {
    return (
        <Layout>
            <h1>Page 2</h1>
        </Layout>
    );
}